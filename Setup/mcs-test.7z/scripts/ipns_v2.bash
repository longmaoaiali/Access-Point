#!/bin/sh
set -uf
#---------------------------------------------------------------------------
# Create a private network namespace for virtual STA
#---------------------------------------------------------------------------
NS=ns$2_$1
nseth0=ns$2_$1eth0
nseth1=ns$2_$1eth1
br=stabr$2
val=`expr 100 + $1`
mval=`echo "obase=16; $1" | bc`
NSIP="192.168.$2.$val"
MAC="00:00:0$2:00:00:$mval"
echo $NS $nseth0 $NSIP
 ip netns add "$NS"
 ip netns exec "$NS" ip li set dev lo up
 ip link add "$nseth0" type veth peer name "$nseth1"
 ip link set "$nseth1" netns "$NS"
 ip li set up dev "$nseth0"
 ip netns exec "$NS" ip addr add $NSIP/16 dev "$nseth1"
 ip netns exec "$NS" ifconfig "$nseth1" hw ether $MAC
  ip netns exec "$NS" ip li set up dev "$nseth1"
 ip netns exec "$NS" ip ro add default via 192.168.1.5 dev "$nseth1"
 ip link set dev "$nseth0" master "$br"

#ip route add 10.8.0.0/24 via 192.168.1.1 dev nseth1

#  route to reach private vpn server network running in tplink router.
#ip netns exec "$ns" ip route add 192.168.1.0/24 via 192.168.3.2 dev "$nsth1"
