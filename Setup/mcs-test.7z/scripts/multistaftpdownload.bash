#!/bin/bash
#Start of for loop
while true
do
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration No $a"
	sudo ip netns exec ns$3_$a sshpass -p "t-span123" scp qctest@10.201.64.218:Client_Simulator/* FTP_Download_Files/Client$a/ &
	sleep 1
done
sleep 300
for (( b=1; b<=$2; b++ ))
do
	echo "Deleting Files No $b"
	cd FTP_Download_Files/Client$b/
	rm *
	cd ../..
done
sleep 5
done
