#!/bin/sh
echo $1
cnt=1
while [ $cnt -le $1 ]; do
    cntx=`printf "%x\n" $cnt`
    MAC="00:00:01:00:$cntx:$cntx"
    echo $MAC
    wrapd -S -g /var/run/wrapdglobal -A $MAC
#    sleep 1
    cnt=$((cnt + 1))
done
