#!/bin/bash
#Start of for loop

while true
do
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sudo ip netns exec ns$2_$a ping 192.168.1.1 -c $3 &
done
sleep 10
done 
