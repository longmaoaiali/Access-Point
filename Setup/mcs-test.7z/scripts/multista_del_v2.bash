#!/bin/bash
#Start of for loop

for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sh ipns_del_v2.sh $a $2
done
