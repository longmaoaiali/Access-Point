#!/bin/sh
set -uf
#---------------------------------------------------------------------------
# Create a private network namespace for virtual STA
#---------------------------------------------------------------------------
NS=ns$2_$1
br=stabr$2
nseth0=ns$1eth0
nseth1=ns$1eth1
val=`expr 100 + $1`
NSIP="192.168.$2.$val"
echo $NS $nseth0 $NSIP
 ip netns del "$NS"
