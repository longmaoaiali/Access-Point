#!/bin/sh
set -uf
#---------------------------------------------------------------------------
# Create a private network namespace for virtual STA
#---------------------------------------------------------------------------
NS=ns$1
nseth0=ns$1eth0
nseth1=ns$1eth1
ifconfig "$nseth0" down
ifconfig "$nseth1" down
brctl delif newbr "$nseth0"
brctl delif newbr "$nseth1"
