#!/bin/sh
set -uf
#---------------------------------------------------------------------------
# Create a private network namespace for virtual STA
#---------------------------------------------------------------------------
NS=ns$1
nseth0=ns$1eth0
nseth1=ns$1eth1
br=newbr
val=`expr 200 + $1`
NSIP="192.168.1.$val"
echo $NS $nseth0 $NSIP
 ip netns del "$NS"
