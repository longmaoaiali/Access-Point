while true
do
	brctl addif stabr2 enx0050b613ae4d 
	sleep 1
	brctl addif stabr1 enx0050b613aeb3
	sleep 1 
	brctl addif stabr3 enx34298f7006be
	sleep 10
done
