#!/bin/bash
#Start of for loop

for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sudo ip netns exec ns$2_$a /usr/local/Ixia/endpoint -n &
	sleep 1
done
