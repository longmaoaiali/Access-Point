#!/bin/bash
#Start of for loop
while true
do
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration No $a"
	sudo ip netns exec ns$2_$a sshpass -p "t-span123" scp FTP_Upload_Files/* qctest@10.201.64.218:Client_Simulator/Client$a/ & 
	sleep 1
done
sleep 1800
done
