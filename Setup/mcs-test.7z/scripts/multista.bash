#!/bin/bash
#Start of for loop
brctl addbr newbr
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sh ipns.sh $a
done
