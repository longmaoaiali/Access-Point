#!/bin/bash
#Start of for loop

while true
do 
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sudo ip netns exec ns$2_$a iperf3 -c 192.168.1.250 -i 1 -u -S 224 -w 256k -t $2 -p $a &
    sleep 1
done
sleep 10
done 
