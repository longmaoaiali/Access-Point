#!/bin/bash
#Start of for loop

for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sh interfaces_clear.sh $a
done
