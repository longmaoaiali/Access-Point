#!/bin/bash
#Start of for loop
brctl addbr stabr$2
for (( a=1; a<=$1; a++ ))
do
    echo "Iteration no $a"
    sh ipns_v2.bash $a $2
done
